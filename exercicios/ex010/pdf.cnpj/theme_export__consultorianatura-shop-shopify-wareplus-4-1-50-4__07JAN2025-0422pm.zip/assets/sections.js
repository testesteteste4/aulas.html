/* Instagram Feed */
const initInstagramGallery = () => {
    document.querySelectorAll('.instagram-feed').forEach(section => {
        const element = section.querySelector('.splide')

        let speed = Number(element.dataset.speed)

        if (element.dataset.direction === 'right') {
            speed = -Math.abs(speed)
        }

        const mySplide = new Splide(element, {
            type: 'loop',
            drag: 'free',
            focus: 'center',
            arrows: element.dataset.arrows === 'true',
            pagination: false,
            easing: element.dataset.easing,
            gap: Number(element.dataset.gap),
            mediaQuery: 'min',
            breakpoints: {
                0: { perPage: Number(element.dataset.breakpointXs), padding: 0 },
                576: { perPage: Number(element.dataset.breakpointSm), padding: 0 },
                768: { perPage: Number(element.dataset.breakpointMd), padding: 0 },
                992: { perPage: Number(element.dataset.breakpointLg), padding: 0 },
                1200: { perPage: Number(element.dataset.breakpointXl), padding: 0 },
                1400: { perPage: Number(element.dataset.breakpointXxl), padding: 0 }
            },
            autoScroll: {
                speed
            },
            direction: document.documentElement.getAttribute('dir')
        })
        mySplide.mount(window.splide.Extensions)
    })
}
initInstagramGallery()

document.addEventListener('shopify:section:load', (e) => {
    if (e.target.querySelector('.instagram-feed')) {
        initInstagramGallery()
    }
})

/* TikTok Slider */
const initTikTokSlider = () => {
    document.querySelectorAll('.tiktok-slider').forEach(section => {
        const element = section.querySelector('.splide')

        const mySplide = new Splide(element, {
            arrows: element.dataset.arrows === 'true',
            pagination: false,
            easing: element.dataset.easing,
            perMove: Number(element.dataset.perMove),
            autoplay: element.dataset.autoplay === 'true',
            interval: Number(element.dataset.interval),
            per_move: Number(element.dataset.perMove),
            rewind: element.dataset.rewind === 'true',
            gap: Number(element.dataset.gap),
            mediaQuery: 'min',
            breakpoints: {
                0: { perPage: Number(element.dataset.breakpointXs), padding: '15%' },
                576: { perPage: Number(element.dataset.breakpointSm), padding: 0 },
                768: { perPage: Number(element.dataset.breakpointMd), padding: 0 },
                992: { perPage: Number(element.dataset.breakpointLg), padding: 0 },
                1200: { perPage: Number(element.dataset.breakpointXl), padding: 0 },
                1400: { perPage: Number(element.dataset.breakpointXxl), padding: 0 }
            },
            direction: document.documentElement.getAttribute('dir')
        })
        mySplide.mount()

        section.querySelectorAll('video').forEach(video => {
            const videoWrapper = video.closest('.video-wrapper-tiktok')
            const soundBtn = videoWrapper.querySelector('[data-toggle-sound]')

            video.addEventListener('click', (e) => {
                section.querySelectorAll(`video:not([data-index="${video.dataset.index}"])`).forEach(video => {
                    video.pause()
                    video.closest('.video-wrapper-tiktok').classList.remove('is-playing')
                })

                if (videoWrapper.classList.contains('is-playing')) {
                    video.pause()
                    videoWrapper.classList.remove('is-playing')
                } else {
                    video.play()
                    videoWrapper.classList.add('is-playing')

                    if (section.dataset.volume === 'on') {
                        video.muted = false
                        soundBtn.querySelector('.icon-volume-off').setAttribute('hidden', 'hidden')
                        soundBtn.querySelector('.icon-volume-on').removeAttribute('hidden')
                    }
                }
            })

            soundBtn?.addEventListener('click', () => {
                video.muted = !video.muted

                if (video.muted) {
                    soundBtn.querySelector('.icon-volume-off').removeAttribute('hidden')
                    soundBtn.querySelector('.icon-volume-on').setAttribute('hidden', 'hidden')
                    section.setAttribute('data-volume', 'off')
                } else {
                    soundBtn.querySelector('.icon-volume-off').setAttribute('hidden', 'hidden')
                    soundBtn.querySelector('.icon-volume-on').removeAttribute('hidden')
                    section.setAttribute('data-volume', 'on')
                }
            })
        })

        mySplide.on('moved', (newIndex, prevIndex) => {
            const video = section.querySelector(`video[data-index="${newIndex}"]`)
            const videoWrapper = video.closest('.video-wrapper-tiktok')
            const soundBtn = videoWrapper.querySelector('[data-toggle-sound]')

            if (video) {
                section.querySelectorAll(`video:not([data-index="${newIndex}"])`).forEach(video => {
                    video.muted = true
                    video.pause()
                    video.closest('.video-wrapper-tiktok').classList.remove('is-playing')
                })

                video.play()

                videoWrapper.classList.add('is-playing')

                if (section.dataset.volume === 'on' && !navigator.userAgent.match(/(iPad|iPhone)/g)) {
                    video.muted = false
                    soundBtn.querySelector('.icon-volume-off').setAttribute('hidden', 'hidden')
                    soundBtn.querySelector('.icon-volume-on').removeAttribute('hidden')
                }
            }
        })
    })
}
initTikTokSlider()

document.addEventListener('shopify:section:load', (e) => {
    if (e.target.querySelector('.tiktok-slider')) {
        initTikTokSlider()
    }
})


/*
    Marquee
*/
const initMarqueeSections = () => {
    document.querySelectorAll('.marquee').forEach(section => {
        const list = section.querySelector('ul')
        const marqueeWidth = list.scrollWidth
        const marqueeLength = list.querySelectorAll('li').length

        list.insertAdjacentHTML('beforeEnd', list.innerHTML)
        list.insertAdjacentHTML('beforeEnd', list.innerHTML)

        list.querySelectorAll('li').forEach((item, index) => {
            if (index >= marqueeLength) {
                item.setAttribute('aria-hidden', 'true')
            }
        })

        let translateX = `-${marqueeWidth}`

        if (document.documentElement.getAttribute('dir') === 'rtl') {
            translateX = `${marqueeWidth}`
        }

        let style = `
            <style>
                #marquee-${list.dataset.sectionId} ul {
                    animation-name: marquee-animation-${list.dataset.sectionId};
                    animation-duration: ${list.dataset.animationDuration}s;
                }
                @keyframes marquee-animation-${list.dataset.sectionId} {
                    to { transform: translateX(${translateX}px); }
                }
            </style>
        `
        if (list.dataset.marqueeDirection === 'right') {
            style += `
                <style>
                    @keyframes marquee-animation-${list.dataset.sectionId} {
                        from { transform: translateX(${translateX}px); }    
                        to { transform: 0); }    
                    }
                </style>
            `
        }

        list.insertAdjacentHTML('beforeBegin', style)
    })
}
initMarqueeSections()

document.addEventListener('shopify:section:load', (e) => {
    if (e.target.querySelector('.marquee')) {
        initMarqueeSections()
    }
})


// Lazy load HTMl5 videos
// https://web.dev/lazy-loading-video/
const initVideoLazyLoad = () => {
    const lazyVideos = [].slice.call(document.querySelectorAll('video.lazy-video'))

    if ('IntersectionObserver' in window) {
        const lazyVideoObserver = new IntersectionObserver(function (entries, observer) {
            entries.forEach(function (video) {
                if (video.isIntersecting) {
                    for (const source in video.target.children) {
                        const videoSource = video.target.children[source]
                        if (typeof videoSource.tagName === 'string' && videoSource.tagName === 'SOURCE') {
                            videoSource.src = videoSource.dataset.src
                        }
                    }

                    video.target.load()

                    if (video.target.hasAttribute('data-poster')) {
                        video.target.poster = video.target.dataset.poster
                    }

                    video.target.classList.remove('lazy-video')
                    lazyVideoObserver.unobserve(video.target)
                }
            })
        }, { threshold: 0, rootMargin: '0px 0px 200px 0px' })

        lazyVideos.forEach(function (lazyVideo) {
            lazyVideoObserver.observe(lazyVideo)
        })
    }
}
initVideoLazyLoad()